import 'dart:convert';

enum ItemValueType { fixed, percentage }

class BudgetItem {
  BudgetItem({
    required this.id,
    required this.name,
    required this.valueType,
    required this.unitValue,
    required this.quantity,
    required this.createdAt,
  });

  final String id;
  final String name;
  final ItemValueType valueType;
  final double unitValue;
  final int quantity;
  final DateTime createdAt;

  double totalForFixedBase(double fixedBase) {
    if (valueType == ItemValueType.fixed) {
      return unitValue * quantity;
    }
    return fixedBase * (unitValue / 100) * quantity;
  }

  BudgetItem copyWith({
    String? id,
    String? name,
    ItemValueType? valueType,
    double? unitValue,
    int? quantity,
    DateTime? createdAt,
  }) {
    return BudgetItem(
      id: id ?? this.id,
      name: name ?? this.name,
      valueType: valueType ?? this.valueType,
      unitValue: unitValue ?? this.unitValue,
      quantity: quantity ?? this.quantity,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'valueType': valueType.name,
      'unitValue': unitValue,
      'quantity': quantity,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory BudgetItem.fromMap(Map<String, dynamic> map) {
    return BudgetItem(
      id: map['id'] as String,
      name: map['name'] as String,
      valueType: ItemValueType.values.firstWhere(
        (e) => e.name == map['valueType'],
        orElse: () => ItemValueType.fixed,
      ),
      unitValue: (map['unitValue'] as num).toDouble(),
      quantity: (map['quantity'] as num).toInt(),
      createdAt: DateTime.parse(map['createdAt'] as String),
    );
  }

  String toJson() => jsonEncode(toMap());

  factory BudgetItem.fromJson(String source) =>
      BudgetItem.fromMap(jsonDecode(source) as Map<String, dynamic>);
}

// ====== NOVOS CAMPOS E REGRA ======
extension BudgetItemCalc on BudgetItem {
  double get unitTotal {
    if (executionLabel == null || executionLabel == 'Sem passar fio') {
      return price;
    }

    if (additionalType == 'fixed') {
      return price + additionalValue;
    } else if (additionalType == 'percent') {
      return price + (price * additionalValue / 100);
    }

    return price;
  }
}
import 'dart:convert';

enum ItemValueType { fixed, percentage }

enum ItemExecutionMode { withoutWiring, withWiring }

enum ItemAdditionalType { fixed, percentage }

class BudgetItem {
  BudgetItem({
    required this.id,
    required this.name,
    required this.valueType,
    required this.unitValue,
    required this.quantity,
    required this.createdAt,
    this.executionMode = ItemExecutionMode.withoutWiring,
    this.additionalType,
    this.additionalValue = 0,
  });

  final String id;
  final String name;
  final ItemValueType valueType;
  final double unitValue;
  final int quantity;
  final DateTime createdAt;
  final ItemExecutionMode executionMode;
  final ItemAdditionalType? additionalType;
  final double additionalValue;

  bool get hasAdditional =>
      executionMode == ItemExecutionMode.withWiring && additionalValue > 0;

  String get executionLabel =>
      executionMode == ItemExecutionMode.withWiring
          ? 'Com passar fio'
          : 'Sem passar fio';

  String get additionalLabel {
    if (!hasAdditional || additionalType == null) return '';
    if (additionalType == ItemAdditionalType.fixed) {
      return 'Adicional fixo';
    }
    return 'Adicional percentual';
  }

  double unitBaseForFixedBase(double fixedBase) {
    if (valueType == ItemValueType.fixed) return unitValue;
    return fixedBase * (unitValue / 100);
  }

  double additionalAmountForUnit(double baseUnit) {
    if (!hasAdditional || additionalType == null) return 0;
    if (additionalType == ItemAdditionalType.fixed) return additionalValue;
    return baseUnit * (additionalValue / 100);
  }

  double effectiveUnitValue(double fixedBase) {
    final baseUnit = unitBaseForFixedBase(fixedBase);
    return baseUnit + additionalAmountForUnit(baseUnit);
  }

  double totalForFixedBase(double fixedBase) {
    return effectiveUnitValue(fixedBase) * quantity;
  }

  BudgetItem copyWith({
    String? id,
    String? name,
    ItemValueType? valueType,
    double? unitValue,
    int? quantity,
    DateTime? createdAt,
    ItemExecutionMode? executionMode,
    Object? additionalType = _sentinel,
    double? additionalValue,
  }) {
    return BudgetItem(
      id: id ?? this.id,
      name: name ?? this.name,
      valueType: valueType ?? this.valueType,
      unitValue: unitValue ?? this.unitValue,
      quantity: quantity ?? this.quantity,
      createdAt: createdAt ?? this.createdAt,
      executionMode: executionMode ?? this.executionMode,
      additionalType: identical(additionalType, _sentinel)
          ? this.additionalType
          : additionalType as ItemAdditionalType?,
      additionalValue: additionalValue ?? this.additionalValue,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'valueType': valueType.name,
      'unitValue': unitValue,
      'quantity': quantity,
      'createdAt': createdAt.toIso8601String(),
      'executionMode': executionMode.name,
      'additionalType': additionalType?.name,
      'additionalValue': additionalValue,
    };
  }

  factory BudgetItem.fromMap(Map<String, dynamic> map) {
    return BudgetItem(
      id: map['id'] as String,
      name: map['name'] as String,
      valueType: ItemValueType.values.firstWhere(
        (e) => e.name == map['valueType'],
        orElse: () => ItemValueType.fixed,
      ),
      unitValue: (map['unitValue'] as num).toDouble(),
      quantity: (map['quantity'] as num).toInt(),
      createdAt: DateTime.parse(map['createdAt'] as String),
      executionMode: ItemExecutionMode.values.firstWhere(
        (e) => e.name == (map['executionMode'] as String? ?? 'withoutWiring'),
        orElse: () => ItemExecutionMode.withoutWiring,
      ),
      additionalType: map['additionalType'] == null
          ? null
          : ItemAdditionalType.values.firstWhere(
              (e) => e.name == map['additionalType'],
              orElse: () => ItemAdditionalType.fixed,
            ),
      additionalValue: (map['additionalValue'] as num?)?.toDouble() ?? 0,
    );
  }

  String toJson() => jsonEncode(toMap());

  factory BudgetItem.fromJson(String source) =>
      BudgetItem.fromMap(jsonDecode(source) as Map<String, dynamic>);
}

const _sentinel = Object();


  double get unitTotal {
    if (executionLabel == 'Sem passar fio') {
      return value;
    }

    if (additionalType == 'fixed') {
      return value + additionalValue;
    }

    if (additionalType == 'percent') {
      return value + (value * additionalValue / 100);
    }

    return value;
  }
