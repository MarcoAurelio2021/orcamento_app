import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../app/app_state.dart';
import '../models/budget.dart';
import '../models/budget_item.dart';
import 'widgets/app_section_card.dart';
import 'widgets/totals_card.dart';

class BudgetsScreen extends StatefulWidget {
  const BudgetsScreen({super.key});

  @override
  State<BudgetsScreen> createState() => _BudgetsScreenState();
}

class _BudgetsScreenState extends State<BudgetsScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _filter = 'Todos';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final currency = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    final date = DateFormat('dd/MM/yyyy');

    final budgets = appState.budgets.where((budget) {
      final query = _searchController.text.trim().toLowerCase();
      final matchesText = query.isEmpty ||
          budget.number.toLowerCase().contains(query) ||
          budget.clientName.toLowerCase().contains(query) ||
          date.format(budget.createdAt).contains(query);

      if (!matchesText) return false;

      final now = DateTime.now();
      if (_filter == 'Hoje') {
        return budget.createdAt.year == now.year &&
            budget.createdAt.month == now.month &&
            budget.createdAt.day == now.day;
      }
      if (_filter == 'Semana') {
        return budget.createdAt.isAfter(now.subtract(const Duration(days: 7)));
      }
      if (_filter == 'Mês') {
        return budget.createdAt.month == now.month &&
            budget.createdAt.year == now.year;
      }
      return true;
    }).toList();

    return Column(
      children: [
        AppSectionCard(
          title: 'Orçamentos criados',
          subtitle:
              'Pesquise por número, cliente ou data e role a lista sem perder o campo de busca.',
          child: Column(
            children: [
              TextField(
                controller: _searchController,
                decoration: const InputDecoration(
                  labelText: 'Pesquisar por número, cliente ou data',
                  prefixIcon: Icon(Icons.search),
                ),
                onChanged: (_) => setState(() {}),
              ),
              const SizedBox(height: 12),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Wrap(
                  spacing: 8,
                  children: ['Todos', 'Hoje', 'Semana', 'Mês']
                      .map(
                        (label) => ChoiceChip(
                          label: Text(label),
                          selected: _filter == label,
                          onSelected: (_) => setState(() => _filter = label),
                        ),
                      )
                      .toList(),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: budgets.isEmpty
              ? const Center(child: Text('Nenhum orçamento encontrado.'))
              : ListView.separated(
                  itemCount: budgets.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final budget = budgets[index];
                    return InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () => _openBudgetDetails(context, budget),
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      budget.number,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w800,
                                        fontSize: 16,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(budget.clientName),
                                    const SizedBox(height: 4),
                                    Text(
                                      date.format(budget.createdAt),
                                      style: const TextStyle(
                                        color: Colors.black54,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 12),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    currency.format(budget.totalFinal),
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  IconButton(
                                    onPressed: () =>
                                        _confirmDelete(context, budget.id),
                                    icon: const Icon(Icons.delete_outline),
                                    tooltip: 'Excluir',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Future<void> _confirmDelete(BuildContext context, String id) async {
    final appState = context.read<AppState>();
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Excluir orçamento'),
        content: const Text(
          'Tem certeza que deseja excluir este orçamento?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await appState.deleteBudget(id);

      if (!context.mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Orçamento excluído.')),
      );
    }
  }

  Future<void> _openBudgetDetails(BuildContext context, Budget budget) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => BudgetDetailsScreen(initialBudget: budget),
      ),
    );
  }
}

class BudgetDetailsScreen extends StatefulWidget {
  const BudgetDetailsScreen({super.key, required this.initialBudget});

  final Budget initialBudget;

  @override
  State<BudgetDetailsScreen> createState() => _BudgetDetailsScreenState();
}

class _BudgetDetailsScreenState extends State<BudgetDetailsScreen> {
  late final TextEditingController _clientController;
  late final TextEditingController _technicianController;
  late final TextEditingController _addressController;
  late final TextEditingController _paymentController;
  late final TextEditingController _notesController;
  late final TextEditingController _discountController;

  late DiscountType _discountType;
  late List<BudgetItem> _items;
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    final budget = widget.initialBudget;
    _clientController = TextEditingController(text: budget.clientName);
    _technicianController = TextEditingController(text: budget.technician);
    _addressController = TextEditingController(text: budget.address);
    _paymentController = TextEditingController(text: budget.paymentMethod);
    _notesController = TextEditingController(text: budget.notes);
    _discountController = TextEditingController(
      text: budget.discountValue.toStringAsFixed(2),
    );
    _discountType = budget.discountType;
    _items = budget.items.map((e) => e.copyWith()).toList();
  }

  @override
  void dispose() {
    _clientController.dispose();
    _technicianController.dispose();
    _addressController.dispose();
    _paymentController.dispose();
    _notesController.dispose();
    _discountController.dispose();
    super.dispose();
  }

  double get _discountValue =>
      double.tryParse(_discountController.text.replaceAll(',', '.')) ?? 0;

  Budget _currentBudget() {
    return widget.initialBudget.copyWith(
      clientName: _clientController.text.trim(),
      technician: _technicianController.text.trim(),
      address: _addressController.text.trim(),
      paymentMethod: _paymentController.text.trim(),
      notes: _notesController.text.trim(),
      discountType: _discountType,
      discountValue: _discountValue,
      items: _items,
    );
  }

  Future<void> _editItem(BudgetItem item) async {
    final valueController = TextEditingController(
      text: item.unitValue.toStringAsFixed(2),
    );
    final quantityController = TextEditingController(
      text: item.quantity.toString(),
    );
    var type = item.valueType;

    final updated = await showDialog<BudgetItem>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Editar item'),
        content: StatefulBuilder(
          builder: (context, setLocalState) => SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  item.name,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                SegmentedButton<ItemValueType>(
                  segments: const [
                    ButtonSegment(
                      value: ItemValueType.fixed,
                      label: Text('Valor fixo'),
                    ),
                    ButtonSegment(
                      value: ItemValueType.percentage,
                      label: Text('Percentual'),
                    ),
                  ],
                  selected: {type},
                  onSelectionChanged: (value) =>
                      setLocalState(() => type = value.first),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: valueController,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration: InputDecoration(
                    labelText: type == ItemValueType.fixed
                        ? 'Valor unitário'
                        : 'Percentual (%)',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: quantityController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Quantidade'),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () {
              final value =
                  double.tryParse(valueController.text.replaceAll(',', '.'));
              final quantity = int.tryParse(quantityController.text);
              if (value == null || quantity == null || quantity <= 0) return;
              Navigator.pop(
                dialogContext,
                item.copyWith(
                  valueType: type,
                  unitValue: value,
                  quantity: quantity,
                ),
              );
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );

    valueController.dispose();
    quantityController.dispose();

    if (updated != null) {
      setState(() {
        _items = _items
            .map((element) => element.id == item.id ? updated : element)
            .toList();
      });
    }
  }

  Future<void> _addNewItem() async {
    final serviceController = TextEditingController();
    final valueController = TextEditingController();
    final quantityController = TextEditingController(text: '1');
    var type = ItemValueType.fixed;
    final appState = context.read<AppState>();

    final created = await showDialog<BudgetItem>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Adicionar item'),
        content: StatefulBuilder(
          builder: (context, setLocalState) => SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: serviceController,
                  decoration: const InputDecoration(labelText: 'Serviço'),
                ),
                const SizedBox(height: 12),
                SegmentedButton<ItemValueType>(
                  segments: const [
                    ButtonSegment(
                      value: ItemValueType.fixed,
                      label: Text('Valor fixo'),
                    ),
                    ButtonSegment(
                      value: ItemValueType.percentage,
                      label: Text('Percentual'),
                    ),
                  ],
                  selected: {type},
                  onSelectionChanged: (value) =>
                      setLocalState(() => type = value.first),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: valueController,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration: InputDecoration(
                    labelText: type == ItemValueType.fixed
                        ? 'Valor unitário'
                        : 'Percentual (%)',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: quantityController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Quantidade'),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () {
              final value =
                  double.tryParse(valueController.text.replaceAll(',', '.'));
              final quantity = int.tryParse(quantityController.text);
              if (serviceController.text.trim().isEmpty ||
                  value == null ||
                  quantity == null ||
                  quantity <= 0) {
                return;
              }
              Navigator.pop(
                dialogContext,
                appState.createItem(
                  name: serviceController.text.trim(),
                  valueType: type,
                  unitValue: value,
                  quantity: quantity,
                ),
              );
            },
            child: const Text('Adicionar'),
          ),
        ],
      ),
    );

    serviceController.dispose();
    valueController.dispose();
    quantityController.dispose();

    if (created != null) {
      setState(() => _items = [..._items, created]);
    }
  }

  @override
  Widget build(BuildContext context) {
    final budget = _currentBudget();
    final currency = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    final date = DateFormat('dd/MM/yyyy HH:mm');

    return Scaffold(
      appBar: AppBar(title: Text(budget.number)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppSectionCard(
            title: 'Dados do orçamento',
            subtitle:
                'Visualize ou edite as informações do cliente e do orçamento.',
            trailing: TextButton.icon(
              onPressed: () => setState(() => _isEditing = !_isEditing),
              icon: Icon(
                _isEditing ? Icons.visibility_outlined : Icons.edit_outlined,
              ),
              label: Text(_isEditing ? 'Modo visualização' : 'Editar'),
            ),
            child: Column(
              children: [
                TextField(
                  controller: _clientController,
                  enabled: _isEditing,
                  decoration: const InputDecoration(
                    labelText: 'Nome do cliente',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _technicianController,
                  enabled: _isEditing,
                  decoration: const InputDecoration(labelText: 'Técnico'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _addressController,
                  enabled: _isEditing,
                  decoration: const InputDecoration(labelText: 'Endereço'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _paymentController,
                  enabled: _isEditing,
                  decoration: const InputDecoration(
                    labelText: 'Forma de pagamento',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _notesController,
                  enabled: _isEditing,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: 'Observações'),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    SizedBox(
                      width: 300,
                      child: SegmentedButton<DiscountType>(
                        segments: const [
                          ButtonSegment(
                            value: DiscountType.fixed,
                            label: Text('Valor fixo'),
                          ),
                          ButtonSegment(
                            value: DiscountType.percentage,
                            label: Text('Percentual (%)'),
                          ),
                        ],
                        selected: {_discountType},
                        onSelectionChanged: _isEditing
                            ? (value) =>
                                setState(() => _discountType = value.first)
                            : null,
                      ),
                    ),
                    SizedBox(
                      width: 220,
                      child: TextField(
                        controller: _discountController,
                        enabled: _isEditing,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'Desconto',
                        ),
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Criado em ${date.format(widget.initialBudget.createdAt)}',
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          AppSectionCard(
            title: 'Itens do orçamento',
            subtitle:
                'Edite quantidade, valor unitário e remova itens já existentes.',
            trailing: _isEditing
                ? TextButton.icon(
                    onPressed: _addNewItem,
                    icon: const Icon(Icons.add),
                    label: const Text('Adicionar item'),
                  )
                : null,
            child: Column(
              children: [
                ..._items.map(
                  (item) => Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                item.name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                            Text(
                              currency.format(
                                item.totalForFixedBase(budget.fixedSubtotal),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          item.valueType == ItemValueType.fixed
                              ? 'Qtd ${item.quantity} • ${currency.format(item.unitValue)}'
                              : 'Qtd ${item.quantity} • ${item.unitValue.toStringAsFixed(2)}%',
                        ),
                        if (_isEditing) ...[
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 12,
                            children: [
                              OutlinedButton.icon(
                                onPressed: () => _editItem(item),
                                icon: const Icon(Icons.edit_outlined),
                                label: const Text('Editar item'),
                              ),
                              TextButton.icon(
                                onPressed: () => setState(
                                  () => _items.removeWhere(
                                    (element) => element.id == item.id,
                                  ),
                                ),
                                icon: const Icon(Icons.delete_outline),
                                label: const Text('Excluir'),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                TotalsCard(
                  subtotal: budget.subtotal,
                  discount: budget.discountApplied,
                  total: budget.totalFinal,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              SizedBox(
                width: 220,
                child: ElevatedButton.icon(
                  onPressed: _isEditing
                      ? () async {
                          await context.read<AppState>().updateBudget(budget);

                          if (!context.mounted) return;

                          setState(() => _isEditing = false);

                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Edição salva com sucesso.'),
                            ),
                          );
                        }
                      : null,
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('Salvar edição'),
                ),
              ),
              SizedBox(
                width: 220,
                child: OutlinedButton.icon(
                  onPressed:
                      _isEditing ? () => Navigator.of(context).pop() : null,
                  icon: const Icon(Icons.cancel_outlined),
                  label: const Text('Cancelar edição'),
                ),
              ),
              SizedBox(
                width: 220,
                child: TextButton.icon(
                  onPressed: () async {
                    await context
                        .read<AppState>()
                        .deleteBudget(widget.initialBudget.id);

                    if (!context.mounted) return;

                    Navigator.of(context).pop();
                  },
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Excluir'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
