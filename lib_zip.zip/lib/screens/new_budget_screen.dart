import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../app/app_state.dart';
import '../models/budget.dart';
import '../models/budget_item.dart';
import '../models/service_type.dart';
import 'widgets/app_section_card.dart';
import 'widgets/info_chip.dart';
import 'widgets/totals_card.dart';

class NewBudgetScreen extends StatefulWidget {
  const NewBudgetScreen({super.key});

  @override
  State<NewBudgetScreen> createState() => _NewBudgetScreenState();
}

class _NewBudgetScreenState extends State<NewBudgetScreen> {
  final _clientController = TextEditingController();
  final _technicianController = TextEditingController();
  final _addressController = TextEditingController();
  final _paymentController = TextEditingController();
  final _notesController = TextEditingController();
  final _serviceController = TextEditingController();
  final _valueController = TextEditingController();
  final _quantityController = TextEditingController(text: '1');
  final _discountController = TextEditingController(text: '0');

  final _clientFormKey = GlobalKey<FormState>();
  final _itemFormKey = GlobalKey<FormState>();

  bool _started = false;
  DiscountType _discountType = DiscountType.fixed;
  ItemValueType _itemValueType = ItemValueType.fixed;
  List<BudgetItem> _items = [];

  @override
  void dispose() {
    _clientController.dispose();
    _technicianController.dispose();
    _addressController.dispose();
    _paymentController.dispose();
    _notesController.dispose();
    _serviceController.dispose();
    _valueController.dispose();
    _quantityController.dispose();
    _discountController.dispose();
    super.dispose();
  }

  double get _discountValue => double.tryParse(_discountController.text.replaceAll(',', '.')) ?? 0;

  double get _fixedSubtotal => _items
      .where((item) => item.valueType == ItemValueType.fixed)
      .fold<double>(0, (sum, item) => sum + item.totalForFixedBase(0));

  double get _percentageSubtotal => _items
      .where((item) => item.valueType == ItemValueType.percentage)
      .fold<double>(0, (sum, item) => sum + item.totalForFixedBase(_fixedSubtotal));

  double get _subtotal => _fixedSubtotal + _percentageSubtotal;

  double get _discountApplied {
    if (_discountType == DiscountType.fixed) return _discountValue.clamp(0, _subtotal);
    return (_subtotal * (_discountValue / 100)).clamp(0, _subtotal);
  }

  double get _totalFinal => (_subtotal - _discountApplied).clamp(0, double.infinity);

  void _startBudget() {
    if (_clientFormKey.currentState?.validate() ?? false) {
      setState(() => _started = true);
    }
  }

  void _loadServiceSuggestion(ServiceType service) {
    _serviceController.text = service.name;
    _itemValueType = service.valueType;
    _valueController.text = service.defaultValue.toStringAsFixed(2);
    setState(() {});
  }

  void _addItem(AppState appState) {
    if (!(_itemFormKey.currentState?.validate() ?? false)) return;
    final value = double.parse(_valueController.text.replaceAll(',', '.'));
    final quantity = int.parse(_quantityController.text);

    final item = appState.createItem(
      name: _serviceController.text.trim(),
      valueType: _itemValueType,
      unitValue: value,
      quantity: quantity,
    );

    setState(() {
      _items = [..._items, item];
      _serviceController.clear();
      _valueController.clear();
      _quantityController.text = '1';
      _itemValueType = ItemValueType.fixed;
    });
  }

  Future<void> _editItem(BudgetItem item) async {
    final serviceController = TextEditingController(text: item.name);
    final valueController = TextEditingController(text: item.unitValue.toStringAsFixed(2));
    final quantityController = TextEditingController(text: item.quantity.toString());
    var type = item.valueType;

    final updated = await showDialog<BudgetItem>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Editar item'),
        content: StatefulBuilder(
          builder: (context, setLocalState) => SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: serviceController, decoration: const InputDecoration(labelText: 'Tipo de serviço')),
                const SizedBox(height: 12),
                SegmentedButton<ItemValueType>(
                  segments: const [
                    ButtonSegment(value: ItemValueType.fixed, label: Text('Valor fixo')),
                    ButtonSegment(value: ItemValueType.percentage, label: Text('Percentual')),
                  ],
                  selected: {type},
                  onSelectionChanged: (value) => setLocalState(() => type = value.first),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: valueController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(labelText: type == ItemValueType.fixed ? 'Valor unitário' : 'Percentual (%)'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: quantityController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Quantidade'),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(
            onPressed: () {
              final value = double.tryParse(valueController.text.replaceAll(',', '.'));
              final quantity = int.tryParse(quantityController.text);
              if (serviceController.text.trim().isEmpty || value == null || quantity == null || quantity <= 0) return;
              Navigator.pop(
                context,
                item.copyWith(
                  name: serviceController.text.trim(),
                  valueType: type,
                  unitValue: value,
                  quantity: quantity,
                ),
              );
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );

    if (updated != null) {
      setState(() {
        _items = _items.map((element) => element.id == item.id ? updated : element).toList();
      });
    }
  }

  void _removeItem(String id) {
    setState(() => _items.removeWhere((item) => item.id == id));
  }

  void _clearAll() {
    setState(() {
      _started = false;
      _items = [];
      _discountType = DiscountType.fixed;
      _itemValueType = ItemValueType.fixed;
      _clientController.clear();
      _technicianController.clear();
      _addressController.clear();
      _paymentController.clear();
      _notesController.clear();
      _serviceController.clear();
      _valueController.clear();
      _quantityController.text = '1';
      _discountController.text = '0';
    });
  }

  Future<void> _saveBudget(AppState appState) async {
    if (_clientController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Informe o nome do cliente.')));
      return;
    }
    if (_items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Adicione pelo menos um item.')));
      return;
    }

    final draft = appState.buildDraftBudget(
      clientName: _clientController.text.trim(),
      technician: _technicianController.text.trim(),
      address: _addressController.text.trim(),
      paymentMethod: _paymentController.text.trim(),
      notes: _notesController.text.trim(),
      discountType: _discountType,
      discountValue: _discountValue,
      items: _items,
    );

    final saved = await appState.createBudget(draft);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Orçamento ${saved.number} salvo com sucesso.')));
    _clearAll();
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final currency = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');

    return ListView(
      children: [
        if (!_started)
          AppSectionCard(
            title: 'Cadastro de orçamento',
            subtitle: 'Preencha os dados iniciais e comece um novo orçamento.',
            child: Form(
              key: _clientFormKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _clientController,
                    decoration: const InputDecoration(labelText: 'Nome do cliente'),
                    validator: (value) => (value == null || value.trim().isEmpty) ? 'Informe o cliente' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(controller: _technicianController, decoration: const InputDecoration(labelText: 'Técnico')),
                  const SizedBox(height: 12),
                  TextFormField(controller: _addressController, decoration: const InputDecoration(labelText: 'Endereço')),
                  const SizedBox(height: 12),
                  TextFormField(controller: _paymentController, decoration: const InputDecoration(labelText: 'Forma de pagamento')),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _notesController,
                    minLines: 2,
                    maxLines: 4,
                    decoration: const InputDecoration(labelText: 'Observações'),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(onPressed: _startBudget, child: const Text('Iniciar orçamento')),
                ],
              ),
            ),
          )
        else
          AppSectionCard(
            title: 'Resumo do cliente',
            subtitle: 'Os dados continuam acessíveis para edição sem poluir a tela.',
            trailing: TextButton.icon(
              onPressed: () => setState(() => _started = false),
              icon: const Icon(Icons.edit_outlined),
              label: const Text('Editar'),
            ),
            child: Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                SizedBox(width: 220, child: InfoChip(label: 'Cliente', value: _clientController.text.trim())),
                SizedBox(width: 220, child: InfoChip(label: 'Técnico', value: _technicianController.text.trim())),
                SizedBox(width: 280, child: InfoChip(label: 'Endereço', value: _addressController.text.trim())),
                SizedBox(width: 220, child: InfoChip(label: 'Pagamento', value: _paymentController.text.trim())),
              ],
            ),
          ),
        const SizedBox(height: 16),
        AppSectionCard(
          title: 'Relatório do orçamento',
          subtitle: 'Adicione itens, gerencie quantidades e acompanhe os totais em tempo real.',
          child: Column(
            children: [
              Form(
                key: _itemFormKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Autocomplete<String>(
                      optionsBuilder: (textEditingValue) {
                        if (textEditingValue.text.isEmpty) {
                          return appState.itemSuggestions.take(8);
                        }
                        return appState.itemSuggestions.where(
                          (option) => option.toLowerCase().contains(textEditingValue.text.toLowerCase()),
                        );
                      },
                      onSelected: (selection) {
                        _serviceController.text = selection;
                        final found = appState.services.cast<ServiceType?>().firstWhere(
                              (service) => service?.name.toLowerCase() == selection.toLowerCase(),
                              orElse: () => null,
                            );
                        if (found != null) {
                          _loadServiceSuggestion(found);
                        }
                      },
                      fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
                        controller.text = _serviceController.text;
                        controller.selection = TextSelection.collapsed(offset: controller.text.length);
                        controller.addListener(() => _serviceController.text = controller.text);
                        return TextFormField(
                          controller: controller,
                          focusNode: focusNode,
                          decoration: const InputDecoration(labelText: 'Tipo de serviço'),
                          validator: (value) => (value == null || value.trim().isEmpty) ? 'Informe o serviço' : null,
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        SizedBox(
                          width: 320,
                          child: SegmentedButton<ItemValueType>(
                            segments: const [
                              ButtonSegment(value: ItemValueType.fixed, label: Text('Valor fixo')),
                              ButtonSegment(value: ItemValueType.percentage, label: Text('Percentual (%)')),
                            ],
                            selected: {_itemValueType},
                            onSelectionChanged: (value) => setState(() => _itemValueType = value.first),
                          ),
                        ),
                        SizedBox(
                          width: 220,
                          child: TextFormField(
                            controller: _valueController,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: InputDecoration(
                              labelText: _itemValueType == ItemValueType.fixed ? 'Valor unitário' : 'Percentual (%)',
                            ),
                            validator: (value) {
                              final parsed = double.tryParse((value ?? '').replaceAll(',', '.'));
                              if (parsed == null || parsed < 0) return 'Valor inválido';
                              return null;
                            },
                          ),
                        ),
                        SizedBox(
                          width: 160,
                          child: TextFormField(
                            controller: _quantityController,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(labelText: 'Quantidade'),
                            validator: (value) {
                              final parsed = int.tryParse(value ?? '');
                              if (parsed == null || parsed <= 0) return 'Qtd inválida';
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: _started ? () => _addItem(appState) : null,
                      icon: const Icon(Icons.add),
                      label: const Text('Adicionar item'),
                    ),
                    if (!_started) ...[
                      const SizedBox(height: 10),
                      const Text('Comece o orçamento antes de adicionar itens.', style: TextStyle(color: Colors.black54)),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Align(
                alignment: Alignment.centerLeft,
                child: Text('Itens adicionados', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
              ),
              const SizedBox(height: 12),
              if (_items.isEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: const Text('Nenhum item adicionado ainda.'),
                )
              else
                Column(
                  children: _items.map((item) {
                    final total = item.totalForFixedBase(_fixedSubtotal);
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Column(
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(item.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                                    const SizedBox(height: 6),
                                    Text(
                                      item.valueType == ItemValueType.fixed
                                          ? 'Valor fixo • ${currency.format(item.unitValue)} • Qtd ${item.quantity}'
                                          : 'Percentual • ${item.unitValue.toStringAsFixed(2)}% • Qtd ${item.quantity}',
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 12),
                              Text(currency.format(total), style: const TextStyle(fontWeight: FontWeight.w800)),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              OutlinedButton.icon(
                                onPressed: () => _editItem(item),
                                icon: const Icon(Icons.edit_outlined),
                                label: const Text('Editar'),
                              ),
                              const SizedBox(width: 12),
                              TextButton.icon(
                                onPressed: () => _removeItem(item.id),
                                icon: const Icon(Icons.delete_outline),
                                label: const Text('Excluir'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              const SizedBox(height: 20),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  SizedBox(
                    width: 320,
                    child: SegmentedButton<DiscountType>(
                      segments: const [
                        ButtonSegment(value: DiscountType.fixed, label: Text('Desconto fixo')),
                        ButtonSegment(value: DiscountType.percentage, label: Text('Desconto %')),
                      ],
                      selected: {_discountType},
                      onSelectionChanged: (value) => setState(() => _discountType = value.first),
                    ),
                  ),
                  SizedBox(
                    width: 220,
                    child: TextField(
                      controller: _discountController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(labelText: 'Desconto'),
                      onChanged: (_) => setState(() {}),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              TotalsCard(subtotal: _subtotal, discount: _discountApplied, total: _totalFinal),
              const SizedBox(height: 20),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  SizedBox(
                    width: 220,
                    child: ElevatedButton.icon(
                      onPressed: _started ? () => _saveBudget(appState) : null,
                      icon: const Icon(Icons.save_outlined),
                      label: const Text('Salvar orçamento'),
                    ),
                  ),
                  SizedBox(
                    width: 220,
                    child: OutlinedButton.icon(
                      onPressed: _clearAll,
                      icon: const Icon(Icons.cancel_outlined),
                      label: const Text('Cancelar orçamento'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
