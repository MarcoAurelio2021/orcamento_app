import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../app/app_state.dart';
import '../models/budget_item.dart';
import '../models/service_type.dart';
import 'widgets/app_section_card.dart';

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  final _nameController = TextEditingController();
  final _valueController = TextEditingController();
  final _searchController = TextEditingController();
  ItemValueType _type = ItemValueType.fixed;

  @override
  void dispose() {
    _nameController.dispose();
    _valueController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _saveService(AppState appState) async {
    final name = _nameController.text.trim();
    final value = double.tryParse(_valueController.text.replaceAll(',', '.'));
    if (name.isEmpty || value == null || value < 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Preencha nome e valor válido.')));
      return;
    }

    final service = appState.createService(name: name, valueType: _type, defaultValue: value);
    await appState.addService(service);
    _nameController.clear();
    _valueController.clear();
    setState(() => _type = ItemValueType.fixed);
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final currency = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    final services = appState.services.where((service) {
      final query = _searchController.text.trim().toLowerCase();
      return query.isEmpty || service.name.toLowerCase().contains(query);
    }).toList();

    return Column(
      children: [
        AppSectionCard(
          title: 'Gerenciar tipos de serviço',
          subtitle: 'Alterações aqui valem apenas para novos orçamentos.',
          child: Column(
            children: [
              TextField(controller: _nameController, decoration: const InputDecoration(labelText: 'Tipo de serviço')),
              const SizedBox(height: 12),
              SegmentedButton<ItemValueType>(
                segments: const [
                  ButtonSegment(value: ItemValueType.fixed, label: Text('Valor fixo')),
                  ButtonSegment(value: ItemValueType.percentage, label: Text('Percentual (%)')),
                ],
                selected: {_type},
                onSelectionChanged: (value) => setState(() => _type = value.first),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _valueController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: _type == ItemValueType.fixed ? 'Campo do valor' : 'Campo do percentual'),
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  SizedBox(
                    width: 220,
                    child: ElevatedButton(onPressed: () => _saveService(appState), child: const Text('Criar serviço')),
                  ),
                  SizedBox(
                    width: 220,
                    child: OutlinedButton(
                      onPressed: () {
                        _nameController.clear();
                        _valueController.clear();
                        setState(() => _type = ItemValueType.fixed);
                      },
                      child: const Text('Limpar'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: AppSectionCard(
            title: 'Lista de serviços',
            subtitle: 'Pesquise, edite ou exclua serviços base.',
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  decoration: const InputDecoration(
                    labelText: 'Pesquisar tipo de serviço',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: services.isEmpty
                      ? const Center(child: Text('Nenhum serviço cadastrado.'))
                      : ListView.separated(
                          itemCount: services.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 10),
                          itemBuilder: (context, index) {
                            final service = services[index];
                            return Card(
                              child: ListTile(
                                title: Text(service.name),
                                subtitle: Text(
                                  service.valueType == ItemValueType.fixed
                                      ? currency.format(service.defaultValue)
                                      : '${service.defaultValue.toStringAsFixed(2)}%',
                                ),
                                trailing: Wrap(
                                  spacing: 8,
                                  children: [
                                    IconButton(
                                      onPressed: () => _showEditDialog(service),
                                      icon: const Icon(Icons.edit_outlined),
                                    ),
                                    IconButton(
                                      onPressed: () => context.read<AppState>().deleteService(service.id),
                                      icon: const Icon(Icons.delete_outline),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _showEditDialog(ServiceType service) async {
    final nameController = TextEditingController(text: service.name);
    final valueController = TextEditingController(text: service.defaultValue.toStringAsFixed(2));
    var type = service.valueType;
    final appState = context.read<AppState>();

    final updated = await showDialog<ServiceType>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Editar serviço'),
        content: StatefulBuilder(
          builder: (context, setLocalState) => SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Tipo de serviço')),
                const SizedBox(height: 12),
                SegmentedButton<ItemValueType>(
                  segments: const [
                    ButtonSegment(value: ItemValueType.fixed, label: Text('Valor fixo')),
                    ButtonSegment(value: ItemValueType.percentage, label: Text('Percentual')),
                  ],
                  selected: {type},
                  onSelectionChanged: (value) => setLocalState(() => type = value.first),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: valueController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(labelText: type == ItemValueType.fixed ? 'Valor' : 'Percentual (%)'),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(
            onPressed: () {
              final value = double.tryParse(valueController.text.replaceAll(',', '.'));
              if (nameController.text.trim().isEmpty || value == null || value < 0) return;
              Navigator.pop(
                context,
                service.copyWith(name: nameController.text.trim(), valueType: type, defaultValue: value),
              );
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );

    if (updated != null) {
      await appState.updateService(updated);
    }
  }
}
